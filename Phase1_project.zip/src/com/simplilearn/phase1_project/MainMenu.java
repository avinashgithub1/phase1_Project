package com.simplilearn.phase1_project;

public class MainMenu {

}
